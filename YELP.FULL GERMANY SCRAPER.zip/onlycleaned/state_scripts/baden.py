"""
Yelp.de Universal Germany Scraper  ·  v10.0
============================================
Changes from v9.3 → v10.0:
  • SPEED: stylesheet blocked (BLOCKED_RESOURCES now includes "stylesheet")
  • SPEED: CSV flush only every 100 saves (was every row) — huge I/O gain
  • SPEED: context recycled every 200 detail pages (was 50)
  • SPEED: scroll reduced to single [600] step on detail pages (was 3 steps)
  • SPEED: listing scroll reduced to single [500] step (was 2)
  • SPEED: delays default changed to min=0 max=0.05
  • SPEED: default workers raised to 6 (was 4)
  • FEATURE: Website email scraping integrated from yelp_pipeline.py
             If a business has a website URL, a WebsiteWorker visits it
             (homepage + /kontakt + /impressum + /contact) and extracts
             real email + fax. Runs as a parallel stage alongside detail scraping.
  • FEATURE: --website-workers N flag (default 4) controls email scraping parallelism
  • FEATURE: --skip-email flag to disable website email scraping entirely
  • LOGS: clean, minimal — only what matters (saving, errors, stats)
  • LOGS: removed per-business duplicate noise; only errors and saves shown
  • CMD: recommended command at bottom of this header

Recommended command (16GB RAM):
  python yelp.py --all-germany --pages 999 --workers 6 --website-workers 4 --resume --output germany
"""

from __future__ import annotations

import asyncio
import argparse
import csv
import html
import json
import logging
import os
import re
import random
import signal
import tempfile
import time
from dataclasses import dataclass, asdict
from datetime import timedelta
from pathlib import Path
from typing import Optional
from urllib.parse import unquote

__version__ = "10.0"

import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment
from playwright.async_api import (
    async_playwright, Browser, BrowserContext, Page,
    TimeoutError as PWTimeout,
)

# ── logging: clean, minimal ──────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(worker_id)-4s] %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("yelp")

_WORKER_LOCAL: dict[int, str] = {}
_orig_factory = logging.getLogRecordFactory()

def _record_factory(*args, **kwargs):
    record = _orig_factory(*args, **kwargs)
    task = asyncio.current_task()
    record.worker_id = _WORKER_LOCAL.get(id(task), "-") if task else "-"
    return record

logging.setLogRecordFactory(_record_factory)

# silence noisy sub-loggers
for _noisy in ("asyncio", "playwright"):
    logging.getLogger(_noisy).setLevel(logging.ERROR)

# ── constants ────────────────────────────────────────────────────────────────
BASE_URL       = "https://www.yelp.de"
CHECKPOINT_DIR = Path("checkpoints_v10")
ORGANIC_ATTR   = '[data-traffic-crawl-id="OrganicBusinessResult"]'

# stylesheet added for speed
BLOCKED_RESOURCES = {"image", "media", "font", "stylesheet", "ping", "cspviolationreport"}
BLOCKED_DOMAINS_RE = re.compile(
    r"(google-analytics|googlesyndication|doubleclick|facebook\.net|"
    r"amplitude|segment\.io|mixpanel|hotjar|newrelic|datadog|sentry)"
)

EMAIL_RE = re.compile(r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}", re.I)
FAX_RE   = re.compile(r"(?:fax|telefax)[:\s]*([+\d][\d\s\-\/\(\)]{5,20})", re.I)

VIEWPORTS = [
    {"width": 1280, "height": 800},
    {"width": 1366, "height": 768},
    {"width": 1440, "height": 900},
    {"width": 1920, "height": 1080},
]

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36 Edg/123.0.0.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0",
]

CAPTCHA_SIGNALS = [
    "captcha", "robot", "unusual traffic", "verify you are human",
    "bitte bestätigen", "access denied", "too many requests", "blocked",
]

# ── geo data ─────────────────────────────────────────────────────────────────
CITIES_BY_STATE: dict[str, list[str]] = {
    "Baden-Württemberg": [
    "Heidelberg",
    "Heilbronn",
    "Pforzheim",
    "Ulm",
    "Reutlingen",
    "Esslingen am Neckar",
    "Ludwigsburg",
    "Tübingen",
    "Konstanz",
    "Villingen-Schwenningen",
    "Aalen",
    "Göppingen",
    "Sindelfingen",
    "Friedrichshafen",
    "Offenburg",
    "Rastatt",
    "Baden-Baden",
    "Lörrach",
    "Ravensburg",
    "Böblingen",
    "Waiblingen",
    "Fellbach",
    "Backnang",
    "Winnenden",
    "Schorndorf",
    "Bietigheim-Bissingen",
    "Kornwestheim",
    "Vaihingen an der Enz",
    "Leonberg",
    "Filderstadt",
    "Leinfelden-Echterdingen",
    "Ostfildern",
    "Nürtingen",
    "Kirchheim unter Teck",
    "Geislingen an der Steige",
    "Schwäbisch Gmünd",
    "Ellwangen (Jagst)",
    "Hechingen",
    "Balingen",
    "Albstadt",
    "Rottenburg am Neckar",
    "Mössingen",
    "Metzingen",
    "Bad Urach",
    "Tuttlingen",
    "Spaichingen",
    "Rottweil",
    "Schramberg",
    "Donaueschingen",
    "Triberg im Schwarzwald",
    "Furtwangen im Schwarzwald",
    "Kehl",
    "Achern",
    "Lahr/Schwarzwald",
    "Gengenbach",
    "Oberkirch",
    "Emmendingen",
    "Waldkirch",
    "Titisee-Neustadt",
    "Breisach am Rhein",
    "Calw",
    "Nagold",
    "Freudenstadt",
    "Mühlacker",
    "Bruchsal",
    "Bretten",
    "Ettlingen",
    "Mosbach",
    "Sinsheim",
    "Schwetzingen",
    "Weinheim",
    "Wiesloch",
    "Walldorf",
    "Radolfzell am Bodensee",
    "Singen (Hohentwiel)",
    "Stockach",
    "Überlingen",
    "Meersburg",
    "Markdorf",
    "Tettnang",
    "Wangen im Allgäu",
    "Leutkirch im Allgäu",
    "Weingarten",
    "Bad Waldsee",
    "Aulendorf",
    "Isny im Allgäu",
    "Sigmaringen",
    "Bad Saulgau",
    "Pfullendorf",
    "Mengen",
    "Laupheim",
    "Biberach an der Riß",
    "Ehingen (Donau)",
    "Blaubeuren",
    "Waldshut-Tiengen",
    "Bad Säckingen",
    "Rheinfelden (Baden)",
    "Weil am Rhein",
    "Schopfheim",
    "Öhringen",
    "Crailsheim",
    "Schwäbisch Hall",
    "Bad Mergentheim",
    "Tauberbischofsheim",
    "Neckarsulm"

    ],
}
CITY_TO_STATE: dict[str, str] = {
    city: state
    for state, cities in CITIES_BY_STATE.items()
    for city in cities
}
GERMAN_STATES = list(CITIES_BY_STATE.keys())

ALL_CATEGORIES: list[str] = [
    "Restaurant", "Café", "Bar", "Pizzeria", "Sushi", "Bäckerei",
    "Konditorei", "Imbiss", "Bistro", "Kneipe", "Weinbar", "Cocktailbar",
    "Steakhouse", "Burger", "Döner", "Asiatisch", "Indisch", "Griechisch",
    "Italienisch", "Mexikanisch", "Türkisch", "Vietnamesisch", "Chinesisch",
    "Spanisch", "Brauerei", "Eisdiele", "Frühstück", "Catering", "Food Truck",
    "Arztpraxis", "Zahnarzt", "Physiotherapie", "Apotheke", "Optiker",
    "Heilpraktiker", "Psychotherapeut", "Orthopäde", "Hautarzt",
    "Kinderarzt", "Frauenärztin", "Augenarzt", "HNO Arzt",
    "Krankenhaus",
    "Pflegedienst", "Tierarzt", "Tierhandlung",
    "Friseur", "Kosmetikstudio", "Nagelstudio", "Massage", "Spa",
    "Yoga", "Fitnessstudio", "Solarium", "Tattoo", "Piercing",
    "Waxing", "Barbershop",
    "Supermarkt", "Bekleidungsgeschäft", "Schuhgeschäft", "Buchladen",
    "Elektronik", "Möbelgeschäft", "Spielzeug", "Sportartikel",
    "Blumenladen", "Schmuck", "Uhren", "Optik", "Haushaltswaren",
    "Gartencenter", "Baumarkt", "Fahrradladen", "Auto Zubehör",
    "Second Hand", "Antiquitäten", "Kunstgalerie",
    "Unternehmensberatung", "Steuerberater", "Rechtsanwalt",
     "Notar", "Personalberatung", "Buchhaltung",
     "Versicherungsmakler", "Übersetzungsbüro",
    "IT-Dienstleistungen", "Softwareentwicklung", "Webdesign",
    "IT-Beratung",  "Digitalagentur",
    "Marketingagentur", "Werbeagentur", "PR-Agentur", "Druckerei",
    "Grafikdesign", "Fotostudio", "Videoproduktion", "Mediaagentur",
    "Elektriker", "Klempner", "Maler", "Schreiner", "Dachdecker",
    "Fliesenleger", "Heizung Sanitär", "Schlüsseldienst", "Umzug",
    "Reinigungsunternehmen", "Gebäudereinigung",
    "Ingenieurbüro", "Architektur", "Elektroinstallation",
    "Autowerkstatt", "Reifenhandel", "Autohaus", "Autovermietung",
    "Fahrschule", "Tankstelle", "Auto Tuning", "Lackiererei",
    "Schule", "Nachhilfe", "Sprachschule", "Musikschule",
    "Kindergarten", "Kita", "Tanzschule",
    "Innenarchitektur", "Immobilienmakler", "Hausverwaltung",
    "Gartenpflege", "Umzugsunternehmen", "Entrümpelung",
    "Hotel", "Hostel", "Pension", "Ferienwohnung", "Reisebüro",
    "Kino", "Theater", "Museum", "Escape Room", "Bowling",
    "Minigolf", "Kletterhalle", "Kartbahn", "Schwimmbad",
    "Veranstaltungsraum", "Diskothek",
    "Bank", "Sparkasse", "Versicherung", 
    "Logistik", "Spedition", "Großhandel", "Kurierdienst",
    "Schneider", "Schuhmacher", "Wäscherei",
    "Bestattung", "Hochzeitsfotograf", "Veranstaltungsplanung",
    # additional categories relevant to BW suburban/industrial region
    "Unternehmensberater", "Steuerberatung", "Kanzlei", "Notariat",
    "Maschinenbau", "Metallbau", 
    "Kfz-Gutachter", "Fahrzeugbewertung", "Pannenhilfe",
    "Wintergarten", "Fenster", "Türen", "Rolladen",
    "Küchenstudio",  "Sanitär", 
    "Raumausstatter", "Bodenbelag", "Parkett", "Teppich",
    "Klimaanlage", "Kamin",
    "Sicherheitsdienst", "Alarmanlage", "Videoüberwachung",
    "Pflegeheim", "Seniorenresidenz", "Betreutes Wohnen", "Sozialstation",
    "Ergotherapie", "Logopädie", "Podologie", "Osteopathie",
    "Hundeschule", "Tierpension", "Tierphysiotherapie",
    "Fahrradwerkstatt", "E-Bike", "Motorradwerkstatt",
    "Bootfahrschule", "Flugschule", "Reitschule",
    "Weinhandel", "Feinkost", "Naturkost", "Biomarkt",
    "Spielhalle", "Fitnesskurs", "Kampfsport", "Crossfit",
    "Kindergarteneinrichtung", "Tagesmutter", "Hort",
    "Nachhilfeinstitut", "Lernstudio", "Berufsschule",
    "Druckerei", 
    "Eventcatering", "Partyservice",
    "Gebäudemanagement", "Facility Management", "Hausmeisterservice",
    "Entsorgung", "Schrotthandel", "Recycling",
    "Immobilienbewertung", "Sachverständiger",
]
_seen: set[str] = set()
ALL_CATEGORIES = [x for x in ALL_CATEGORIES if not (x in _seen or _seen.add(x))]  # type: ignore[func-returns-value]
# ── data model ───────────────────────────────────────────────────────────────
@dataclass
class Business:
    name:        str = ""
    strasse:     str = ""
    plz:         str = ""
    ort:         str = ""
    bundesland:  str = ""
    telefon:     str = ""
    telefax:     str = ""
    email:       str = ""
    webseite:    str = ""
    branche:     str = ""
    bewertung:   str = ""
    bewertungen: str = ""
    source_url:  str = ""

XLSX_HEADERS = ["Name", "Straße", "PLZ", "Ort", "Bundesland", "Telefon", "Telefax", "E-Mail", "Webseite", "Branche"]
XLSX_FIELDS  = ["name", "strasse", "plz", "ort", "bundesland", "telefon", "telefax", "email", "webseite", "branche"]
CSV_FIELDS   = XLSX_FIELDS + ["bewertung", "bewertungen", "source_url"]
COL_WIDTHS   = [35, 28, 8, 20, 22, 18, 18, 30, 40, 22]

# ── utils ────────────────────────────────────────────────────────────────────
def clean(text: str) -> str:
    return re.sub(r"\s+", " ", (text or "").strip())

def normalise_phone(raw: str) -> str:
    return re.sub(r"[^\d\s\+\-\/\(\)]", "", raw).strip()

def normalise_plz(raw: str) -> str:
    m = re.search(r"\b(\d{4,5})\b", raw)
    return m.group(1) if m else raw.strip()

def normalise_url(raw: str) -> str:
    raw = raw.strip()
    if raw and not raw.startswith("http"):
        raw = "https://" + raw
    return raw

def normalise_email(raw: str) -> str:
    raw = raw.strip().lower()
    return raw if "@" in raw else ""

def parse_address(raw: str) -> tuple[str, str, str]:
    raw = clean(raw)
    m = re.search(r"^(.*?),?\s*(\d{4,5})\s+(.+)$", raw)
    if m:
        return m.group(1).strip(), m.group(2).strip(), m.group(3).strip()
    m2 = re.search(r"(\d{4,5})\s+(.+)", raw)
    if m2:
        return "", m2.group(1).strip(), m2.group(2).strip()
    return raw, "", ""

def guess_bundesland(city: str, location_arg: str) -> str:
    for key, state in CITY_TO_STATE.items():
        if key.lower() in city.lower():
            return state
    for state in GERMAN_STATES:
        if state.lower() in location_arg.lower():
            return state
    return ""

def fmt_duration(seconds: float) -> str:
    return str(timedelta(seconds=int(seconds)))

async def human_delay(mn: float = 0.0, mx: float = 0.05) -> None:
    if mx > 0:
        await asyncio.sleep(random.uniform(mn, mx))

_SLUG_RE = re.compile(r"^[a-z0-9]{3,}(-[a-z0-9]{3,}){3,}$")
_GENERIC_NAMES = (
    {c.lower() for c in ALL_CATEGORIES}
    | {s.lower() for s in GERMAN_STATES}
    | {city.lower() for cities in CITIES_BY_STATE.values() for city in cities}
)

def has_valid_name(biz: "Business") -> bool:
    name = (biz.name or "").strip()
    if not name or len(name) < 3:
        return False
    if _SLUG_RE.match(name.lower()):
        return False
    if name.lower() in _GENERIC_NAMES:
        has_data = any([
            (biz.strasse  or "").strip(),
            (biz.plz      or "").strip(),
            (biz.telefon  or "").strip(),
            (biz.webseite or "").strip(),
        ])
        if not has_data:
            return False
    return True

def slug_to_name(url: str) -> str:
    slug = url.split("/biz/")[-1].split("?")[0]
    slug = unquote(slug)
    if not re.search(r"[a-z]{2,}-[a-z]", slug):
        return ""
    slug = re.sub(r"-\d+$", "", slug)
    parts = [p for p in slug.split("-") if p]
    if len(parts) > 1 and re.fullmatch(r"[a-z]+", parts[-1]):
        parts = parts[:-1]
    return " ".join(p.capitalize() for p in parts)

def valid_email(email: str) -> bool:
    email = email.lower().strip()
    bad = ("example", "test@", "noreply", "no-reply", ".png", ".jpg", ".jpeg", ".gif", ".webp")
    return "@" in email and "." in email.split("@")[-1] and not any(x in email for x in bad)

async def is_blocked(page: Page) -> bool:
    try:
        title   = (await page.title()).lower()
        content = (await page.content()).lower()
        for sig in CAPTCHA_SIGNALS:
            if sig in title or sig in content[:2000]:
                return True
        if any(x in page.url for x in ["/503", "/error", "/block"]):
            return True
    except Exception:
        pass
    return False

# ── XLSX builder ─────────────────────────────────────────────────────────────
def atomic_save(wb: openpyxl.Workbook, target: str) -> bool:
    p = Path(target)
    fd, tmp = tempfile.mkstemp(suffix=".xlsx", dir=p.parent, prefix=".tmp_yelp_")
    os.close(fd)
    try:
        wb.save(tmp)
        Path(tmp).replace(p)
        return True
    except PermissionError:
        log.warning("XLSX locked (open in Excel?). Saved to temp: %s", tmp)
        return False
    except Exception as exc:
        log.error("XLSX save error: %s", exc)
        try: Path(tmp).unlink(missing_ok=True)
        except: pass
        return False

def build_xlsx_from_csv(csv_path: str, xlsx_path: str) -> None:
    log.info("Building Excel from CSV...")
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Yelp DE"
    hfill = PatternFill("solid", fgColor="1F4E79")
    hfont = Font(color="FFFFFF", bold=True, name="Arial", size=10)
    for ci, h in enumerate(XLSX_HEADERS, 1):
        cell = ws.cell(row=1, column=ci, value=h)
        cell.fill      = hfill
        cell.font      = hfont
        cell.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 18
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{chr(64+len(XLSX_HEADERS))}1"
    for ci, w in enumerate(COL_WIDTHS, 1):
        ws.column_dimensions[chr(64+ci)].width = w
    alt   = PatternFill("solid", fgColor="EBF3FB")
    nfont = Font(name="Arial", size=10)
    with open(csv_path, newline="", encoding="utf-8-sig") as fh:
        reader = csv.DictReader(fh)
        for row_idx, row in enumerate(reader, 2):
            for ci, fname in enumerate(XLSX_FIELDS, 1):
                cell = ws.cell(row=row_idx, column=ci, value=row.get(fname) or "")
                cell.font = nfont
                if row_idx % 2 == 0:
                    cell.fill = alt
    atomic_save(wb, xlsx_path)
    log.info("Excel saved → %s", xlsx_path)

# ── OutputManager ─────────────────────────────────────────────────────────────
class OutputManager:
    FLUSH_EVERY = 100  # flush CSV every N saves (was every row — big speed gain)

    def __init__(self, xlsx_path: Optional[str], csv_path: Optional[str],
                 noname_csv_path: Optional[str] = None) -> None:
        self._lock      = asyncio.Lock()
        self._xlsx_path = xlsx_path
        self._csv_path  = csv_path
        self.saved      = 0
        self._wb = None
        self._ws = None
        self._csv_fh     = None
        self._csv_writer = None
        if csv_path:
            exists = Path(csv_path).exists()
            self._csv_fh     = open(csv_path, "a", newline="", encoding="utf-8-sig")
            self._csv_writer = csv.DictWriter(self._csv_fh, fieldnames=CSV_FIELDS, extrasaction="ignore")
            if not exists:
                self._csv_writer.writeheader()
                self._csv_fh.flush()
        self._noname_fh     = None
        self._noname_writer = None
        if noname_csv_path:
            exists = Path(noname_csv_path).exists()
            self._noname_fh     = open(noname_csv_path, "a", newline="", encoding="utf-8-sig")
            self._noname_writer = csv.DictWriter(self._noname_fh, fieldnames=CSV_FIELDS, extrasaction="ignore")
            if not exists:
                self._noname_writer.writeheader()
                self._noname_fh.flush()

    async def save(self, biz: Business) -> None:
        async with self._lock:
            d = asdict(biz)
            if self._csv_writer:
                self._csv_writer.writerow(d)
                self.saved += 1
                if self.saved % self.FLUSH_EVERY == 0:
                    self._csv_fh.flush()

    async def patch_email_live(self, source_url: str, email: str, fax: str) -> None:
        """Immediately rewrite CSV injecting email/fax for the matching source_url row.
        Called by WebsiteWorker as soon as an email is found — no waiting until end of run.
        """
        if not self._csv_path or not email:
            return
        async with self._lock:
            # ── close append handle FIRST so Windows releases the file lock ──
            if self._csv_fh:
                try:
                    self._csv_fh.flush()
                    self._csv_fh.close()
                except Exception:
                    pass
                self._csv_fh     = None
                self._csv_writer = None

            tmp = self._csv_path + ".patching"
            patched = False
            try:
                with open(self._csv_path, newline="", encoding="utf-8-sig") as fin, \
                     open(tmp, "w", newline="", encoding="utf-8-sig") as fout:
                    reader = csv.DictReader(fin)
                    writer = csv.DictWriter(fout, fieldnames=reader.fieldnames or CSV_FIELDS,
                                            extrasaction="ignore")
                    writer.writeheader()
                    for row in reader:
                        if row.get("source_url", "") == source_url:
                            if email and not row.get("email"):
                                row["email"] = email
                                patched = True
                            if fax and not row.get("telefax"):
                                row["telefax"] = fax
                        writer.writerow(row)

                # ── Windows-safe atomic rename with short retry (AV/Explorer hold) ──
                for attempt in range(5):
                    try:
                        Path(tmp).replace(self._csv_path)
                        break
                    except PermissionError:
                        if attempt == 4:
                            raise
                        time.sleep(0.2 * (attempt + 1))

            except Exception as e:
                log.warning("Live email patch failed: %s", e)
                try: Path(tmp).unlink(missing_ok=True)
                except: pass
            finally:
                # ── always reopen append handle, even if patch failed ──
                self._csv_fh = open(self._csv_path, "a", newline="", encoding="utf-8-sig")
                self._csv_writer = csv.DictWriter(self._csv_fh, fieldnames=CSV_FIELDS,
                                                  extrasaction="ignore")

            if patched:
                log.info("Patched email live → %s", source_url[-60:])

    async def save_noname(self, biz: Business) -> None:
        async with self._lock:
            if self._noname_writer:
                self._noname_writer.writerow(asdict(biz))
                if self._noname_fh:
                    # noname writes are infrequent — flush each time is fine
                    self._noname_fh.flush()

    async def flush(self) -> None:
        async with self._lock:
            if self._csv_fh:
                self._csv_fh.flush()
            if self._noname_fh:
                self._noname_fh.flush()

    def close(self) -> None:
        if self._csv_fh:
            self._csv_fh.flush()
            self._csv_fh.close()
        if self._noname_fh:
            self._noname_fh.flush()
            self._noname_fh.close()

# ── ProgressTracker ──────────────────────────────────────────────────────────
class ProgressTracker:
    FLUSH_EVERY = 10

    def __init__(self, path: Path) -> None:
        self._path      = path
        self._lock      = asyncio.Lock()
        self._done      : set[str] = set()
        self._completed = 0
        if path.exists():
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
                self._done = set(data.get("done", []))
                log.info("Checkpoint loaded: %d tasks done", len(self._done))
            except Exception as e:
                log.warning("Checkpoint load failed: %s", e)

    @staticmethod
    def task_key(location: str, query: str, page_num: int) -> str:
        return f"{location}||{query}||{page_num}"

    async def is_done(self, location: str, query: str, page_num: int) -> bool:
        async with self._lock:
            return self.task_key(location, query, page_num) in self._done

    async def mark_done(self, location: str, query: str, page_num: int) -> None:
        async with self._lock:
            self._done.add(self.task_key(location, query, page_num))
            self._completed += 1
            if self._completed % self.FLUSH_EVERY == 0:
                self._write()

    def _write(self) -> None:
        tmp = self._path.with_suffix(".tmp")
        try:
            tmp.write_text(
                json.dumps({"done": list(self._done)}, ensure_ascii=False),
                encoding="utf-8",
            )
            tmp.replace(self._path)
        except Exception as e:
            log.warning("Checkpoint write failed: %s", e)

    async def flush(self) -> None:
        async with self._lock:
            self._write()

    @property
    def done_count(self) -> int:
        return len(self._done)

# ── DedupStore ───────────────────────────────────────────────────────────────
class DedupStore:
    def __init__(self, path: Optional[Path] = None) -> None:
        self._lock   = asyncio.Lock()
        self._urls   : set[str] = set()
        self._names  : set[str] = set()
        self._phones : set[str] = set()
        self._path   = path
        if path and path.exists():
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
                self._urls   = set(data.get("urls",   []))
                self._names  = set(data.get("names",  []))
                self._phones = set(data.get("phones", []))
                log.info("Dedup loaded: %d URLs", len(self._urls))
            except Exception as e:
                log.warning("Dedup load failed: %s", e)

    async def register_url(self, url: str) -> bool:
        async with self._lock:
            if url in self._urls:
                return False
            self._urls.add(url)
            if len(self._urls) % 1000 == 0:
                self._write()
            return True

    async def is_duplicate(self, biz: Business) -> bool:
        phone_key = re.sub(r"\D", "", biz.telefon)
        name_key  = (biz.name or "").strip().lower()
        async with self._lock:
            if name_key and name_key in self._names:
                return True
            if phone_key and len(phone_key) > 6 and phone_key in self._phones:
                return True
            if name_key:
                self._names.add(name_key)
            if phone_key and len(phone_key) > 6:
                self._phones.add(phone_key)
            return False

    def _write(self) -> None:
        if not self._path:
            return
        tmp = self._path.with_suffix(".tmp")
        try:
            tmp.write_text(
                json.dumps({
                    "urls":   list(self._urls),
                    "names":  list(self._names),
                    "phones": list(self._phones),
                }, ensure_ascii=False),
                encoding="utf-8",
            )
            tmp.replace(self._path)
        except Exception as e:
            log.warning("Dedup write failed: %s", e)

    async def flush(self) -> None:
        async with self._lock:
            self._write()

# ── Stats ─────────────────────────────────────────────────────────────────────
class Stats:
    def __init__(self) -> None:
        self.start_time      = time.time()
        self.links_found     = 0
        self.scraped         = 0
        self.saved           = 0
        self.skipped_dup     = 0
        self.skipped_task    = 0
        self.skipped_name    = 0
        self.retry_queued    = 0
        self.retry_discarded = 0
        self.errors          = 0
        self.emails_found    = 0
        self.web_visited     = 0
        self._lock           = asyncio.Lock()

    async def inc(self, field: str, n: int = 1) -> None:
        async with self._lock:
            setattr(self, field, getattr(self, field) + n)

    def banner(self) -> str:
        elapsed = fmt_duration(time.time() - self.start_time)
        mins    = max((time.time() - self.start_time) / 60, 0.01)
        speed   = f"{self.saved / mins:.1f} biz/min"
        return (
            f"\n{'━'*70}\n"
            f"  FOUND {self.links_found:>6}  SAVED {self.saved:>6}  DUP {self.skipped_dup:>4}  "
            f"NO-NAME {self.skipped_name:>4}  ERR {self.errors:>3}\n"
            f"  EMAIL {self.emails_found:>5}  WEB-VISITED {self.web_visited:>5}  "
            f"SPEED {speed}  RUNTIME {elapsed}\n"
            f"{'━'*70}"
        )

# ── Task ──────────────────────────────────────────────────────────────────────
@dataclass
class Task:
    location: str
    query:    str
    page_num: int

# ── Worker ────────────────────────────────────────────────────────────────────
class Worker:
    BLOCK_PAUSE = 90

    def __init__(
        self, wid: int, browser: Browser,
        dedup: DedupStore, progress: ProgressTracker,
        output: OutputManager, stats: Stats,
        url_queue: asyncio.Queue, detail_queue: asyncio.Queue,
        retry_queue: asyncio.Queue, website_queue: asyncio.Queue,
        args, proxies: Optional[list[str]] = None,
        pause_evt: Optional[asyncio.Event] = None,
        resume_evt: Optional[asyncio.Event] = None,
        pw=None,
    ) -> None:
        self.wid           = wid
        self.browser       = browser
        self.dedup         = dedup
        self.progress      = progress
        self.output        = output
        self.stats         = stats
        self.url_queue     = url_queue
        self.detail_queue  = detail_queue
        self.retry_queue   = retry_queue
        self.website_queue = website_queue
        self.args          = args
        self.proxies       = proxies
        self.pause_evt     = pause_evt
        self.resume_evt    = resume_evt
        self._pw           = pw  # playwright handle for browser relaunch
        self._ctx  : Optional[BrowserContext] = None
        self._page : Optional[Page]           = None
        self._blocked_until: float            = 0.0
        self._detail_count : int              = 0

    async def _wait_if_paused(self) -> None:
        if self.pause_evt and self.pause_evt.is_set():
            if self.resume_evt:
                await self.resume_evt.wait()

    def _log(self, level: str, msg: str, *a) -> None:
        task = asyncio.current_task()
        if task:
            _WORKER_LOCAL[id(task)] = str(self.wid)
        getattr(log, level)(msg, *a)


    async def _relaunch_browser(self) -> None:
        """Close dead browser and relaunch a fresh one for this worker."""
        self._log("warning", "Browser dead — relaunching for worker %d", self.wid)
        try: await self.browser.close()
        except: pass
        self._ctx  = None
        self._page = None
        if self._pw is None:
            raise RuntimeError("No playwright handle — cannot relaunch browser")
        for attempt in range(1, 6):
            try:
                self.browser = await self._pw.chromium.launch(
                    headless=True,
                    args=[
                        "--no-sandbox",
                        "--disable-blink-features=AutomationControlled",
                        "--disable-dev-shm-usage",
                        "--disable-gpu",
                        "--no-first-run",
                        "--disable-extensions",
                        "--disable-background-networking",
                        "--disable-sync",
                        "--mute-audio",
                        "--disable-component-update",
                        "--disable-default-apps",
                        "--memory-pressure-off",
                        "--disable-features=TranslateUI,BlinkGenPropertyTrees",
                        "--js-flags=--max-old-space-size=256",
                        "--renderer-process-limit=4",
                        "--process-per-site",
                    ],
                )
                self._log("info", "Browser relaunched OK (attempt %d)", attempt)
                return
            except Exception as e:
                backoff = min(5.0 * attempt, 30.0)
                self._log("warning", "Relaunch attempt %d failed: %s — retry in %.0fs", attempt, e, backoff)
                await asyncio.sleep(backoff)
        raise RuntimeError("Browser relaunch failed after 5 attempts")

    async def _make_context(self) -> BrowserContext:
        proxy = None
        if self.proxies:
            p = random.choice(self.proxies)
            parts = p.strip().split(":")
            if len(parts) == 2:
                proxy = {"server": f"http://{parts[0]}:{parts[1]}"}
            elif len(parts) == 4:
                proxy = {"server": f"http://{parts[0]}:{parts[1]}", "username": parts[2], "password": parts[3]}
        kwargs: dict = dict(
            user_agent  = random.choice(USER_AGENTS),
            locale      = "de-DE",
            timezone_id = "Europe/Berlin",
            viewport    = random.choice(VIEWPORTS),
        )
        if proxy:
            kwargs["proxy"] = proxy
        ctx = await self.browser.new_context(**kwargs)
        await ctx.add_init_script("""
            Object.defineProperty(navigator, 'webdriver', {get: () => undefined});
            Object.defineProperty(navigator, 'plugins',   {get: () => [1,2,3,4,5]});
            Object.defineProperty(navigator, 'languages', {get: () => ['de-DE','de','en']});
            window.chrome = {runtime: {}};
        """)
        return ctx

    async def _ensure_page(self) -> Page:
        if not self._ctx or not self._page:
            if self._ctx:
                try: await self._ctx.close()
                except: pass
            self._ctx  = await self._make_context()
            self._page = await self._ctx.new_page()
            async def route_handler(route):
                req = route.request
                if req.resource_type in BLOCKED_RESOURCES:
                    await route.abort(); return
                if BLOCKED_DOMAINS_RE.search(req.url):
                    await route.abort(); return
                await route.continue_()
            await self._page.route("**/*", route_handler)
        return self._page

    async def _accept_cookies(self, page: Page) -> None:
        try:
            btn = page.locator(
                "button:has-text('Alle akzeptieren'),"
                "button:has-text('Akzeptieren'),"
                "button[id*='accept']"
            )
            if await btn.first.is_visible(timeout=2_000):
                await btn.first.click()
                await asyncio.sleep(0.2)
        except: pass

    async def _handle_block(self, retry_item: Optional[tuple] = None) -> None:
        pause = self.BLOCK_PAUSE + random.randint(0, 30)
        self._log("warning", "BLOCKED — pausing %ds", pause)
        self._blocked_until = time.time() + pause
        if retry_item is not None:
            url, query_cat, location, attempts = retry_item
            if attempts < 1:
                await self.retry_queue.put((url, query_cat, location, attempts + 1))
                await self.stats.inc("retry_queued")
            else:
                await self.stats.inc("retry_discarded")
        await asyncio.sleep(pause)
        try: await self._ctx.close()
        except: pass
        self._ctx  = None
        self._page = None

    async def _wait_if_blocked(self) -> None:
        rem = self._blocked_until - time.time()
        if rem > 0:
            await asyncio.sleep(rem)

    async def fetch_listing(self, task: Task) -> list[str]:
        await self._wait_if_blocked()
        page  = await self._ensure_page()
        start = task.page_num * 10
        url   = (
            f"{BASE_URL}/search"
            f"?find_desc={task.query.replace(' ', '+')}"
            f"&find_loc={task.location.replace(' ', '+')}"
            f"&start={start}"
        )
        self._log("info", "Listing  %s / %s / pg%d", task.location, task.query, task.page_num + 1)

        try:
            await page.goto(url, wait_until="domcontentloaded", timeout=30_000)
        except PWTimeout:
            return []
        except Exception as nav_exc:
            err_s = str(nav_exc)
            if "Page crashed" in err_s or "MemoryError" in err_s or "Target closed" in err_s:
                try:
                    if self._ctx: await self._ctx.close()
                except: pass
                self._ctx = None; self._page = None
                await asyncio.sleep(random.uniform(3.0, 6.0))
            raise

        if await is_blocked(page):
            await self._handle_block()
            return []

        await self._accept_cookies(page)

        # single scroll pass (speed optimisation)
        try:
            await page.mouse.wheel(0, 500)
            await asyncio.sleep(0.15)
        except: pass

        organic_found = False
        try:
            await page.wait_for_selector(ORGANIC_ATTR, timeout=8_000)
            organic_found = True
        except PWTimeout:
            pass

        if not organic_found:
            truly_empty = await page.evaluate("""() => {
                const body = (document.body && document.body.innerText) || '';
                const signals = [
                    'no results', 'keine ergebnisse', '0 results',
                    "didn't find", 'not find any', 'Try a different',
                    'Leider haben wir', 'Wir haben keine',
                ];
                for (const s of signals) {
                    if (body.toLowerCase().includes(s.toLowerCase())) return true;
                }
                const countEl = document.querySelector(
                    '[class*="resultCount"],[class*="result-count"],' +
                    '[aria-label*="result" i],h1[class*="css-"]'
                );
                if (countEl) {
                    const m = (countEl.innerText || '').match(/^0\\b/);
                    if (m) return true;
                }
                return false;
            }""")
            if truly_empty:
                return []
            try:
                await page.wait_for_selector('a[href*="/biz/"]', timeout=4_000)
            except PWTimeout:
                return []

        container_sel = ORGANIC_ATTR if organic_found else 'main, #main-content, [id*="search-results"], body'

        raw_links: list[str] = await page.eval_on_selector_all(
            f'{container_sel} a[href*="/biz/"]',
            """els => {
                const seen = new Set(), out = [];
                for (const e of els) {
                    try {
                        const u = new URL(e.href);
                        if (/[/](search|login|signup|user_details|photo|map)/.test(u.pathname)) continue;
                        const c = u.origin + u.pathname.replace(/[?].*/, '');
                        if (!seen.has(c)) { seen.add(c); out.push(c); }
                    } catch(e) {}
                }
                return out;
            }"""
        )

        results = []
        for lnk in raw_links:
            full = lnk if lnk.startswith("http") else BASE_URL + lnk
            if await self.dedup.register_url(full):
                results.append(full)

        await self.stats.inc("links_found", len(results))
        if results:
            self._log("info", "  → %d new URLs (pg%d)", len(results), task.page_num + 1)
        return results

    async def scrape_detail(self, url: str, query_cat: str, location: str,
                            attempts: int = 0) -> Optional[Business]:
        await self._wait_if_blocked()
        for attempt in range(1, 4):
            try:
                biz = await self._extract(url, query_cat, location, attempts=attempts)
                if not has_valid_name(biz):
                    derived = slug_to_name(url)
                    if derived and len(derived) >= 3:
                        biz.name = derived
                if not has_valid_name(biz):
                    await self.output.save_noname(biz)
                    await self.stats.inc("skipped_name")
                    return None
                return biz
            except Exception as exc:
                self._log("warning", "[retry %d/3] %s — %s", attempt, url[-60:], exc)
                if attempt < 3:
                    await asyncio.sleep(random.uniform(1.5, 3.0))
                    if attempt == 2:
                        try: await self._ctx.close()
                        except: pass
                        self._ctx = None; self._page = None
        await self.stats.inc("errors")
        return None

    async def _extract(self, url: str, query_cat: str, location: str,
                       attempts: int = 0) -> Business:
        # recycle context every 200 detail pages (was 50 — reduces overhead)
        self._detail_count += 1
        if self._detail_count % 200 == 0:
            self._log("info", "Context recycle at #%d", self._detail_count)
            if self._ctx:
                try: await self._ctx.close()
                except: pass
            self._ctx  = None
            self._page = None

        page = await self._ensure_page()
        try:
            await page.goto(url, wait_until="domcontentloaded", timeout=30_000)
        except Exception as nav_exc:
            err_s = str(nav_exc)
            if "Page crashed" in err_s or "MemoryError" in err_s or "Target closed" in err_s:
                try:
                    if self._ctx: await self._ctx.close()
                except: pass
                self._ctx = None; self._page = None
                await asyncio.sleep(random.uniform(3.0, 6.0))
            raise

        if await is_blocked(page):
            await self._handle_block(retry_item=(url, query_cat, location, attempts))
            raise RuntimeError("Blocked on detail page")

        # single scroll pass — triggers lazy phone/address without 3-step overhead
        try:
            await page.mouse.wheel(0, 600)
            await asyncio.sleep(0.3)
        except: pass

        try:
            await page.wait_for_selector("h1, script[type='application/ld+json'], address", timeout=6_000)
        except: pass

        ex = await page.evaluate(r"""() => {
            const txt = el => (el && (el.innerText || el.textContent || '').trim()) || '';
            const first = (sels, root=document) => {
                for (const s of sels) {
                    try { const e = root.querySelector(s); if (e && txt(e)) return txt(e); } catch(e) {}
                }
                return '';
            };

            let ld = null;
            for (const sc of document.querySelectorAll('script[type="application/ld+json"]')) {
                try {
                    const d = JSON.parse(sc.textContent);
                    const candidates = Array.isArray(d) ? d : (d['@graph'] || [d]);
                    for (const c of candidates) {
                        if (c['@type'] && /LocalBusiness|Restaurant|Store|Organization/i.test(c['@type'])) {
                            ld = c; break;
                        }
                    }
                    if (ld) break;
                } catch(e) {}
            }

            let name = (ld && ld.name) ? ld.name.trim() : '';
            if (!name) name = first([
                'h1[class*="businessName"]', 'h1[class*="heading"]',
                '[data-testid*="business-name"]', '[data-testid="biz-name"]',
                'h1[class*="css-"]', '.biz-page-title', 'h1',
            ]);
            if (!name && document.title) {
                name = document.title.replace(/\s*[-|]\s*Yelp.*$/i, '').replace(/\s*\|\s*.*/i, '').trim();
            }

            let streetAddress = '', postalCode = '', addressLocality = '';
            if (ld && ld.address) {
                const a = ld.address;
                streetAddress   = (a.streetAddress   || '').trim();
                postalCode      = (a.postalCode       || '').trim();
                addressLocality = (a.addressLocality  || '').trim();
            }
            let addr = [streetAddress, postalCode, addressLocality].filter(Boolean).join(', ');
            if (!addr) {
                const sa = document.querySelector('[itemprop="streetAddress"]');
                const pc = document.querySelector('[itemprop="postalCode"]');
                const lo = document.querySelector('[itemprop="addressLocality"]');
                if (sa || pc || lo) addr = [txt(sa), txt(pc), txt(lo)].filter(Boolean).join(', ');
            }
            if (!addr) {
                addr = first(['address','[aria-label*="Adresse" i]','[aria-label*="address" i]',
                              '[class*="mapbox"] p','p[class*="address"]','[class*="css-"] address']);
            }
            addr = addr.replace(/\n+/g, ', ').replace(/\s{2,}/g, ' ').trim();

            let phone = (ld && ld.telephone) ? ld.telephone.trim() : '';
            if (!phone) {
                const telA = document.querySelector('a[href^="tel:"]');
                if (telA) phone = telA.href.replace('tel:', '').trim();
            }
            if (!phone) {
                phone = first(['[aria-label="Telefonnummer"] p','[aria-label="Telefonnummer"]',
                               'p[aria-label*="phone" i]','[aria-label*="telephone" i] p',
                               '[aria-label*="phone" i] p','[class*="phone"] p','p[class*="phone"]']);
            }
            if (!phone) {
                for (const p of document.querySelectorAll('p, span')) {
                    const t = txt(p);
                    if (/^[\d\s\+\-\/\(\)]{7,20}$/.test(t) && /\d{4}/.test(t)) { phone = t; break; }
                }
            }

            let fax = '';
            for (const el of document.querySelectorAll('p,span,li,div')) {
                const t = txt(el);
                if (/\bFax\b|\bTelefax\b/i.test(t)) {
                    const sib   = el.nextElementSibling;
                    const child = el.querySelector('p') || el.querySelector('span');
                    const cand  = txt(sib || child);
                    if (cand && /\d/.test(cand)) { fax = cand; break; }
                    const m = t.match(/Telefax[:\s]+([+\d\s\-\/\(\)]{6,})/i);
                    if (m) { fax = m[1].trim(); break; }
                }
            }

            let email = (ld && ld.email) ? ld.email.trim().toLowerCase() : '';
            if (!email) {
                const ml = document.querySelector('a[href^="mailto:"]');
                if (ml) email = ml.href.replace('mailto:', '').split('?')[0].trim().toLowerCase();
            }

            let website = (ld && ld.url && !ld.url.includes('yelp')) ? ld.url.trim() : '';
            if (!website) {
                for (const s of ['a[href*="biz_redir"]','[aria-label*="website" i] a',
                                  '[aria-label*="Webseite" i] a','[class*="website"] a','a[class*="website"]']) {
                    try {
                        const e = document.querySelector(s);
                        if (e) { website = e.href || ''; break; }
                    } catch(e) {}
                }
                if (website) {
                    const m = website.match(/[?&]url=([^&]+)/);
                    if (m) { try { website = decodeURIComponent(m[1]); } catch(e) {} }
                }
            }

            let cat = '';
            if (ld) {
                const types = [].concat(ld['@type'] || []).filter(t => !/LocalBusiness|Organization/.test(t));
                if (types.length) cat = types.join(', ');
            }
            if (!cat) {
                for (const s of ['[class*="categoryLinks"] a','[class*="category"] a',
                                  'span[class*="tag"] a','a[href*="/c/"]','[class*="css-"] a[href*="find_desc"]']) {
                    try {
                        const els = document.querySelectorAll(s);
                        if (els.length) {
                            cat = Array.from(els).slice(0,3).map(e => txt(e)).filter(Boolean).join(', ');
                            if (cat) break;
                        }
                    } catch(e) {}
                }
            }

            let rating = (ld && ld.aggregateRating) ? String(ld.aggregateRating.ratingValue || '') : '';
            let reviews = (ld && ld.aggregateRating) ? String(ld.aggregateRating.reviewCount || '') : '';
            if (!rating) {
                const re = document.querySelector('[aria-label*="star rating" i],[aria-label*="Sterne" i]');
                if (re) { const m = (re.getAttribute('aria-label') || '').match(/([\d,\.]+)/); if (m) rating = m[1].replace(',', '.'); }
            }
            if (!reviews) {
                const rv = document.querySelector('[class*="reviewCount"],[aria-label*="review" i],[class*="review-count"]');
                if (rv) { const m = txt(rv).match(/(\d+)/); if (m) reviews = m[1]; }
            }

            return {name, addr, phone, fax, email, website, cat, rating, reviews};
        }""")

        b = Business(source_url=url)
        b.name = html.unescape(clean(ex.get("name", "")))

        raw_addr = clean(ex.get("addr", ""))
        if raw_addr:
            b.strasse, b.plz, b.ort = parse_address(raw_addr)
            b.plz = normalise_plz(b.plz)

        b.bundesland = guess_bundesland(b.ort or location, location)

        raw_phone = clean(ex.get("phone", ""))
        if raw_phone and re.search(r"\d{3}", raw_phone):
            b.telefon = normalise_phone(raw_phone)

        raw_fax = clean(ex.get("fax", ""))
        if raw_fax:
            b.telefax = normalise_phone(raw_fax)

        raw_email = clean(ex.get("email", ""))
        if raw_email:
            b.email = normalise_email(raw_email)

        raw_web = clean(ex.get("website", ""))
        if raw_web:
            b.webseite = normalise_url(raw_web)

        cat = clean(ex.get("cat", ""))
        b.branche = cat if cat else query_cat

        b.bewertung   = clean(ex.get("rating", ""))
        b.bewertungen = clean(ex.get("reviews", ""))

        await self.stats.inc("scraped")
        self._log("info", "SAVED %-38s | %-5s %-14s | %s",
                  (b.name or "(no name)")[:38], b.plz, b.ort, b.telefon or "(no phone)")
        return b

    async def run_listing_worker(self) -> None:
        _WORKER_LOCAL[id(asyncio.current_task())] = f"L{self.wid}"
        while True:
            await self._wait_if_paused()
            try:
                task: Task = await asyncio.wait_for(self.url_queue.get(), timeout=5.0)
            except asyncio.TimeoutError:
                return

            try:
                for pg in range(task.page_num, self.args.pages):
                    await self._wait_if_paused()
                    pg_task = Task(location=task.location, query=task.query, page_num=pg)
                    urls = await self.fetch_listing(pg_task)
                    for u in urls:
                        await self.detail_queue.put((u, task.query, task.location))
                    await self.progress.mark_done(task.location, task.query, pg)
                    if not urls:
                        break
                    await human_delay(self.args.min_delay, self.args.max_delay)
            except Exception as exc:
                err_str = str(exc)
                self._log("error", "Listing error: %s", exc)
                if ("ERR_NETWORK" in err_str or "net::" in err_str
                        or "Page crashed" in err_str or "MemoryError" in err_str
                        or "Target closed" in err_str):
                    try:
                        if self._ctx: await self._ctx.close()
                    except: pass
                    self._ctx = None; self._page = None
                    await asyncio.sleep(random.uniform(5.0, 10.0))
                if "Page crashed" not in err_str and "MemoryError" not in err_str:
                    await self.url_queue.put(task)
            finally:
                self.url_queue.task_done()

            await human_delay(self.args.min_delay, self.args.max_delay)

    async def run_detail_worker(self, shutdown_event: asyncio.Event) -> None:
        _WORKER_LOCAL[id(asyncio.current_task())] = f"D{self.wid}"
        while not shutdown_event.is_set():
            try:
                url, query_cat, location = await asyncio.wait_for(
                    self.detail_queue.get(), timeout=3.0
                )
            except asyncio.TimeoutError:
                if self.url_queue.empty() and self.detail_queue.empty():
                    return
                continue

            try:
                biz = await self.scrape_detail(url, query_cat, location)
                if biz is not None:
                    is_dup = await self.dedup.is_duplicate(biz)
                    if is_dup:
                        await self.stats.inc("skipped_dup")
                    else:
                        await self.output.save(biz)
                        await self.stats.inc("saved")
                        # push to website queue for email scraping
                        if biz.webseite and not self.args.skip_email:
                            try:
                                self.website_queue.put_nowait((biz.webseite, biz.source_url))
                            except asyncio.QueueFull:
                                pass
                        if self.args.max_results and self.stats.saved >= self.args.max_results:
                            shutdown_event.set()
            except Exception as exc:
                await self.stats.inc("errors")
                self._log("error", "Detail error: %s", exc)
            finally:
                self.detail_queue.task_done()

            await human_delay(self.args.min_delay * 0.3, self.args.max_delay * 0.3)

        if self._ctx:
            try: await self._ctx.close()
            except: pass

    async def run_retry_worker(self, shutdown_event: asyncio.Event) -> None:
        _WORKER_LOCAL[id(asyncio.current_task())] = f"R{self.wid}"
        while not shutdown_event.is_set():
            try:
                url, query_cat, location, attempts = await asyncio.wait_for(
                    self.retry_queue.get(), timeout=5.0
                )
            except asyncio.TimeoutError:
                if self.url_queue.empty() and self.detail_queue.empty() and self.retry_queue.empty():
                    return
                continue

            await asyncio.sleep(random.uniform(15.0, 30.0))

            try:
                biz = await self.scrape_detail(url, query_cat, location, attempts=attempts)
                if biz is not None:
                    is_dup = await self.dedup.is_duplicate(biz)
                    if not is_dup:
                        await self.output.save(biz)
                        await self.stats.inc("saved")
                        if biz.webseite and not self.args.skip_email:
                            try:
                                self.website_queue.put_nowait((biz.webseite, biz.source_url))
                            except asyncio.QueueFull:
                                pass
                        if self.args.max_results and self.stats.saved >= self.args.max_results:
                            shutdown_event.set()
                    else:
                        await self.stats.inc("skipped_dup")
            except Exception as exc:
                await self.stats.inc("errors")
                self._log("error", "Retry error: %s", exc)
            finally:
                self.retry_queue.task_done()

        if self._ctx:
            try: await self._ctx.close()
            except: pass

def _pick_best_email(emails: set) -> str:
    """Pick the most business-relevant email from a set."""
    if not emails:
        return ""
    priority = ("info@", "kontakt@", "office@", "sales@", "support@", "mail@", "post@")
    sorted_emails = sorted(emails)
    for pref in priority:
        match = next((e for e in sorted_emails if e.startswith(pref)), None)
        if match:
            return match
    return sorted_emails[0]


# ── WebsiteWorker — email scraping from company websites ────────────────────
class WebsiteWorker:
    """
    Visits company website URLs collected during detail scraping.
    Checks homepage + /kontakt + /impressum + /contact for emails and fax.
    Updates the CSV in-place by patching the email column.
    """
    TIMEOUT     = 15_000
    RECYCLE_AT  = 40

    def __init__(self, wid: int, browser: Browser, stats: Stats,
                 output: "OutputManager", shutdown_evt: asyncio.Event,
                 pw=None) -> None:
        self.wid          = wid
        self.browser      = browser
        self.stats        = stats
        self.output       = output
        self.shutdown_evt = shutdown_evt
        self._pw          = pw
        self._ctx  : Optional[BrowserContext] = None
        self._page : Optional[Page]           = None
        self._count: int                      = 0

    async def _relaunch_browser(self) -> None:
        log.warning("WebsiteWorker %d: browser dead — relaunching", self.wid)
        try: await self.browser.close()
        except: pass
        self._ctx  = None
        self._page = None
        if self._pw is None:
            raise RuntimeError("No playwright handle for WebsiteWorker relaunch")
        for attempt in range(1, 6):
            try:
                self.browser = await self._pw.chromium.launch(
                    headless=True,
                    args=[
                        "--no-sandbox", "--disable-dev-shm-usage", "--disable-gpu",
                        "--disable-blink-features=AutomationControlled",
                        "--no-first-run", "--disable-extensions",
                        "--disable-background-networking", "--disable-sync",
                        "--mute-audio", "--disable-component-update",
                        "--disable-default-apps", "--memory-pressure-off",
                        "--disable-features=TranslateUI,BlinkGenPropertyTrees",
                        "--js-flags=--max-old-space-size=256",
                        "--renderer-process-limit=4", "--process-per-site",
                    ],
                )
                log.info("WebsiteWorker %d browser relaunched OK", self.wid)
                return
            except Exception as e:
                await asyncio.sleep(min(5.0 * attempt, 30.0))
        raise RuntimeError("WebsiteWorker browser relaunch failed")

    async def _ensure_page(self) -> Page:
        if not self._ctx or not self._page:
            if self._ctx:
                try: await self._ctx.close()
                except: pass
            try:
                ctx = await self.browser.new_context(
                    user_agent  = random.choice(USER_AGENTS),
                    locale      = "de-DE",
                    timezone_id = "Europe/Berlin",
                    viewport    = random.choice(VIEWPORTS),
                )
            except Exception as e:
                if any(x in str(e) for x in ("closed", "crashed", "disconnected", "Target page", "has been closed")):
                    await self._relaunch_browser()
                    ctx = await self.browser.new_context(
                        user_agent  = random.choice(USER_AGENTS),
                        locale      = "de-DE",
                        timezone_id = "Europe/Berlin",
                        viewport    = random.choice(VIEWPORTS),
                    )
                else:
                    raise
            page = await ctx.new_page()
            # block same resources as main workers
            async def rh(route):
                if route.request.resource_type in BLOCKED_RESOURCES:
                    await route.abort(); return
                if BLOCKED_DOMAINS_RE.search(route.request.url):
                    await route.abort(); return
                await route.continue_()
            await page.route("**/*", rh)
            self._ctx  = ctx
            self._page = page
        return self._page


    async def _recycle(self) -> None:
        if self._ctx:
            try: await self._ctx.close()
            except: pass
        self._ctx  = None
        self._page = None

    async def _scrape_and_patch(self, website: str, source_url: str) -> tuple[str, str]:
        """Run _scrape but patch the CSV immediately when email found on any page,
        without waiting until all pages have been visited."""
        self._count += 1
        if self._count % self.RECYCLE_AT == 0:
            await self._recycle()

        page   = await self._ensure_page()
        base   = website.rstrip("/")
        paths  = ["", "/kontakt", "/contact", "/impressum", "/about", "/legal", "/team", "/datenschutz"]
        found_emails: set[str] = set()
        found_faxes : set[str] = set()
        patched_early = False

        def clean_obfuscation(text: str) -> str:
            text = re.sub(r"\[at\]|\(at\)|\sat\s", "@", text, flags=re.I)
            text = re.sub(r"\[dot\]|\(dot\)|\sdot\s", ".", text, flags=re.I)
            return text

        visited_paths: set[str] = set()

        for path in paths:
            url = base + path
            if url in visited_paths:
                continue
            visited_paths.add(url)

            try:
                try:
                    await page.goto(url, wait_until="domcontentloaded", timeout=self.TIMEOUT)
                except Exception as _nav_exc:
                    _err = str(_nav_exc)
                    if any(x in _err for x in ("Page crashed", "Target closed", "Session closed",
                                                "Connection closed", "has been closed", "crashed")):
                        # browser/page is dead — reset so _ensure_page recreates it
                        try:
                            if self._ctx: await self._ctx.close()
                        except: pass
                        self._ctx = None
                        self._page = None
                        page = await self._ensure_page()
                        await page.goto(url, wait_until="domcontentloaded", timeout=self.TIMEOUT)
                    else:
                        raise

                # mailto links (most reliable)
                try:
                    mailtos = await page.eval_on_selector_all(
                        'a[href^="mailto:"]',
                        "els => els.map(e => e.href)"
                    )
                    for href in mailtos:
                        em = href.replace("mailto:", "").split("?")[0].strip().lower()
                        if valid_email(em):
                            found_emails.add(em)
                except: pass

                # full HTML regex scan
                try:
                    raw_html = await page.content()
                    combined = clean_obfuscation(raw_html)
                    for em in EMAIL_RE.findall(combined):
                        if valid_email(em.lower()):
                            found_emails.add(em.lower())
                    for fax in FAX_RE.findall(combined):
                        fax = fax.strip()
                        if re.search(r"\d{4,}", fax):
                            found_faxes.add(normalise_phone(fax))
                except: pass

                # PATCH IMMEDIATELY as soon as we find email on this page
                if found_emails and not patched_early:
                    best = _pick_best_email(found_emails)
                    fax_now = next(iter(found_faxes), "")
                    await self.output.patch_email_live(source_url, best, fax_now)
                    patched_early = True
                    log.info("EMAIL (live) %-36s → %s", website[:36], best)

                # discover additional contact pages via links on this page
                if not found_emails:
                    try:
                        links = await page.eval_on_selector_all("a[href]", "els => els.map(e => e.href)")
                        kws = ("contact", "kontakt", "impressum", "about", "team", "legal")
                        for link in links[:80]:
                            if (any(k in link.lower() for k in kws)
                                    and link.startswith(base)
                                    and link not in visited_paths):
                                visited_paths.add(link)
                                try:
                                    await page.goto(link, wait_until="domcontentloaded", timeout=10_000)
                                    html2 = clean_obfuscation(await page.content())
                                    for em in EMAIL_RE.findall(html2):
                                        if valid_email(em.lower()):
                                            found_emails.add(em.lower())
                                    # patch immediately from sub-page too
                                    if found_emails and not patched_early:
                                        best = _pick_best_email(found_emails)
                                        fax_now = next(iter(found_faxes), "")
                                        await self.output.patch_email_live(source_url, best, fax_now)
                                        patched_early = True
                                        log.info("EMAIL (live/sub) %-31s → %s", website[:31], best)
                                except: pass
                    except: pass

                if found_emails:
                    break

            except Exception:
                continue

        selected = _pick_best_email(found_emails) if found_emails else ""
        fax_final = next(iter(found_faxes), "")

        # Final patch only if we never patched early (no email on any visited page)
        if selected and not patched_early:
            await self.output.patch_email_live(source_url, selected, fax_final)
        elif fax_final and not patched_early:
            # patch fax even if no email
            await self.output.patch_email_live(source_url, "", fax_final)

        return selected, fax_final

    async def run(self, website_queue: asyncio.Queue, detail_done_evt: asyncio.Event) -> None:
        task = asyncio.current_task()
        if task:
            _WORKER_LOCAL[id(task)] = f"W{self.wid}"

        while not self.shutdown_evt.is_set():
            try:
                website, source_url = await asyncio.wait_for(website_queue.get(), timeout=3.0)
            except asyncio.TimeoutError:
                if detail_done_evt.is_set() and website_queue.empty():
                    break
                continue

            try:
                email, fax = await self._scrape_and_patch(website, source_url)
                await self.stats.inc("web_visited")
                if email:
                    await self.stats.inc("emails_found")
            except Exception as exc:
                log.warning("WebsiteWorker error %s: %s", website, exc)
            finally:
                website_queue.task_done()

        if self._ctx:
            try: await self._ctx.close()
            except: pass


# ── main scraper orchestrator ────────────────────────────────────────────────
async def run_scraper(args) -> None:
    CHECKPOINT_DIR.mkdir(exist_ok=True)

    if args.all_germany:
        locations = [city for cities in CITIES_BY_STATE.values() for city in cities]
    elif args.state:
        locations = CITIES_BY_STATE.get(args.state, [args.state])
    else:
        locations = [args.location]

    queries = [args.query] if args.query else ALL_CATEGORIES

    progress_file = CHECKPOINT_DIR / "progress.json"
    progress      = ProgressTracker(progress_file)
    dedup_file    = CHECKPOINT_DIR / "dedup.json"
    dedup         = DedupStore(dedup_file)

    # Output fixed: Baden-Württemberg
    OUT_DIR = Path(r"D:\onlycleaned")
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    stem = "Baden-Württemberg"

    xlsx_path       = str(OUT_DIR / f"{stem}.xlsx")
    csv_path        = str(OUT_DIR / f"{stem}.csv")
    noname_csv_path = str(OUT_DIR / f"{stem}_noname.csv")
    output = OutputManager(xlsx_path, csv_path, noname_csv_path)
    stats  = Stats()

    proxies: Optional[list[str]] = None
    if args.proxy_list:
        p = Path(args.proxy_list)
        if p.exists():
            proxies = [l.strip() for l in p.read_text().splitlines() if l.strip()]

    total_tasks   = 0
    skipped_tasks = 0
    url_queue    : asyncio.Queue[Task]   = asyncio.Queue()
    detail_queue : asyncio.Queue[tuple]  = asyncio.Queue(maxsize=500)
    retry_queue  : asyncio.Queue[tuple]  = asyncio.Queue()
    website_queue: asyncio.Queue[tuple]  = asyncio.Queue(maxsize=5000)
    shutdown_evt : asyncio.Event         = asyncio.Event()
    detail_done_evt: asyncio.Event       = asyncio.Event()
    pause_evt    : asyncio.Event         = asyncio.Event()
    resume_evt   : asyncio.Event         = asyncio.Event()
    resume_evt.set()
    _sigint_count: int = 0

    for location in locations:
        for query in queries:
            if args.resume and await progress.is_done(location, query, 0):
                skipped_tasks += 1
                await stats.inc("skipped_task")
                continue
            total_tasks += 1
            await url_queue.put(Task(location=location, query=query, page_num=0))

    remaining = total_tasks - skipped_tasks

    print(f"\n{'═'*60}")
    print(f"  Yelp.de Germany Scraper  v{__version__}")
    print(f"  Locations  : {len(locations)}  ({locations[0]}…)")
    print(f"  Categories : {len(queries)}")
    print(f"  Pages/query: {args.pages}")
    print(f"  Workers    : {args.workers} listing + {args.workers} detail + 2 retry")
    print(f"  Web email  : {'OFF (--skip-email)' if args.skip_email else f'{args.website_workers} website workers'}")
    print(f"  Delay      : {args.min_delay}s – {args.max_delay}s")
    print(f"  Resume     : {'ON' if args.resume else 'OFF'}")
    print(f"  Queued     : {remaining} tasks  (skipped done: {skipped_tasks})")
    print(f"  Output CSV : {csv_path}")
    print(f"{'═'*60}\n")

    if remaining == 0:
        print("  All tasks done. Remove checkpoints_v10/ to restart.")
        output.close()
        return

    async def _flush_on_pause():
        await output.flush()
        await dedup.flush()
        await progress.flush()
        log.info("PAUSED — checkpoints saved. Enter to resume, Ctrl+C to quit.")

    async def _stdin_resume():
        loop = asyncio.get_event_loop()
        while not shutdown_evt.is_set():
            try:
                await asyncio.wait_for(loop.run_in_executor(None, input), timeout=1.0)
                if pause_evt.is_set() and not shutdown_evt.is_set():
                    pause_evt.clear()
                    resume_evt.set()
                    print("  RESUMING...", flush=True)
            except (asyncio.TimeoutError, EOFError):
                pass

    def _sigint(sig, frame):
        nonlocal _sigint_count
        _sigint_count += 1
        if _sigint_count == 1:
            print("\n  PAUSED — Ctrl+C again to quit, Enter to resume\n", flush=True)
            pause_evt.set()
            resume_evt.clear()
            asyncio.get_event_loop().call_soon_threadsafe(
                lambda: asyncio.ensure_future(_flush_on_pause())
            )
        else:
            print("\n  QUITTING...\n", flush=True)
            resume_evt.set()
            shutdown_evt.set()

    signal.signal(signal.SIGINT, _sigint)

    async with async_playwright() as pw:
        browser = await pw.chromium.launch(
            headless=not args.visible,
            args=[
                "--no-sandbox",
                "--disable-blink-features=AutomationControlled",
                "--disable-dev-shm-usage",
                "--disable-gpu",
                "--no-first-run",
                "--disable-extensions",
                "--disable-background-networking",
                "--disable-sync",
                "--mute-audio",
                "--disable-component-update",
                "--disable-default-apps",
                "--memory-pressure-off",
                "--disable-features=TranslateUI,BlinkGenPropertyTrees",
                "--js-flags=--max-old-space-size=256",
                "--renderer-process-limit=4",
                "--single-process" if args.workers <= 3 else "--process-per-site",
            ],
        )

        n = args.workers
        listing_workers = [
            Worker(i, browser, dedup, progress, output, stats,
                   url_queue, detail_queue, retry_queue, website_queue, args, proxies,
                   pause_evt=pause_evt, resume_evt=resume_evt, pw=pw)
            for i in range(n)
        ]
        detail_workers = [
            Worker(n + i, browser, dedup, progress, output, stats,
                   url_queue, detail_queue, retry_queue, website_queue, args, proxies,
                   pw=pw)
            for i in range(n)
        ]
        retry_workers = [
            Worker(n * 2 + i, browser, dedup, progress, output, stats,
                   url_queue, detail_queue, retry_queue, website_queue, args, proxies,
                   pw=pw)
            for i in range(2)
        ]
        website_workers = [] if args.skip_email else [
            WebsiteWorker(i, browser, stats, output, shutdown_evt, pw=pw)
            for i in range(args.website_workers)
        ]

        async def print_stats():
            while not shutdown_evt.is_set():
                await asyncio.sleep(30)
                print(stats.banner(), flush=True)

        stats_task    = asyncio.create_task(print_stats())
        stdin_task    = asyncio.create_task(_stdin_resume())
        listing_tasks = [asyncio.create_task(w.run_listing_worker()) for w in listing_workers]
        detail_tasks  = [asyncio.create_task(w.run_detail_worker(shutdown_evt)) for w in detail_workers]
        retry_tasks   = [asyncio.create_task(w.run_retry_worker(shutdown_evt)) for w in retry_workers]
        website_tasks = [asyncio.create_task(w.run(website_queue, detail_done_evt)) for w in website_workers]

        # Stage 1: listing workers finish
        await asyncio.gather(*listing_tasks, return_exceptions=True)
        log.info("Listing done — draining detail queue...")

        # Stage 2: wait for detail queue to drain
        try:
            await asyncio.wait_for(detail_queue.join(), timeout=7200)
        except asyncio.TimeoutError:
            log.warning("Detail drain timeout")

        # Stage 3: drain retry queue
        log.info("Detail done — draining retry queue...")
        try:
            await asyncio.wait_for(retry_queue.join(), timeout=600)
        except asyncio.TimeoutError:
            log.warning("Retry drain timeout")

        # Signal website workers that detail is done
        detail_done_evt.set()

        # Stage 4: wait for website/email workers to finish
        if website_tasks:
            log.info("Waiting for email scraping to finish...")
            try:
                await asyncio.wait_for(website_queue.join(), timeout=3600)
            except asyncio.TimeoutError:
                log.warning("Website queue drain timeout — patching with what we have")
            await asyncio.gather(*website_tasks, return_exceptions=True)

        shutdown_evt.set()
        await asyncio.gather(*detail_tasks, return_exceptions=True)
        await asyncio.gather(*retry_tasks,  return_exceptions=True)
        stats_task.cancel()
        stdin_task.cancel()

        await output.flush()
        await dedup.flush()
        await progress.flush()
        await browser.close()

    output.close()

    # Build final XLSX from (patched) CSV
    if Path(csv_path).exists():
        build_xlsx_from_csv(csv_path, xlsx_path)
    noname_xlsx_path = f"{args.output}_noname.xlsx"
    if Path(noname_csv_path).exists():
        build_xlsx_from_csv(noname_csv_path, noname_xlsx_path)

    print(stats.banner())
    print(f"\n  DONE — {stats.saved} businesses saved  |  {stats.emails_found} emails found")
    print(f"  Excel  → {xlsx_path}")
    print(f"  CSV    → {csv_path}")

# ── CLI ───────────────────────────────────────────────────────────────────────
def parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser(
        description=f"Yelp.de Germany Scraper v{__version__}",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Recommended (16GB RAM, all Germany, max leads + emails):
  python yelp.py --all-germany --pages 999 --workers 6 --website-workers 4 --resume --output germany

Quick test:
  python yelp.py --location Berlin --pages 2 --workers 2 --skip-email

Single state:
  python yelp.py --state Bayern --pages 10 --workers 6 --resume
        """
    )
    loc = ap.add_mutually_exclusive_group()
    loc.add_argument("--all-germany",   action="store_true")
    loc.add_argument("--state",         default="Baden-Württemberg")
    loc.add_argument("--location",      default="Stuttgart")

    ap.add_argument("--query",           default=None)
    ap.add_argument("--pages",           type=int,   default=999,
                    help="Max pages per query/city combo (default: 999 = scrape until empty)")
    ap.add_argument("--workers",         type=int,   default=6,
                    help="Listing + detail workers (default: 6; use 4 if RAM issues)")
    ap.add_argument("--website-workers", type=int,   default=4, dest="website_workers",
                    help="Parallel website email-scraping workers (default: 4)")
    ap.add_argument("--skip-email",      action="store_true", dest="skip_email",
                    help="Disable website email scraping (faster, no email column)")
    ap.add_argument("--output",          default="yelp_germany",
                    help='Output filename stem (default: yelp_germany)')
    ap.add_argument("--visible",         action="store_true",
                    help="Show browser (default: headless)")
    ap.add_argument("--resume",          action="store_true",
                    help="Resume from checkpoint")
    ap.add_argument("--max-results",     type=int,   default=0)
    ap.add_argument("--min-delay",       type=float, default=0.0, dest="min_delay")
    ap.add_argument("--max-delay",       type=float, default=0.05, dest="max_delay")
    ap.add_argument("--proxy-list",      default=None)
    ap.add_argument("--list-categories", action="store_true")
    ap.add_argument("--list-cities",     action="store_true")
    return ap.parse_args()


def main() -> None:
    args = parse_args()
    if args.list_categories:
        print(f"\n{len(ALL_CATEGORIES)} categories:\n")
        for c in ALL_CATEGORIES: print(f"  {c}")
        return
    if args.list_cities:
        cities = [c for cs in CITIES_BY_STATE.values() for c in cs]
        print(f"\n{len(cities)} cities:\n")
        for c in cities: print(f"  {c}")
        return
    asyncio.run(run_scraper(args))


if __name__ == "__main__":
    main()